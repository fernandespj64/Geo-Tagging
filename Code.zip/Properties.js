[mysql]
host=localhost
user=root
password=root
database=geo_tagging