var express = require('express');
var app = express();
var mysql = require('mysql');
var inside = require('point-in-polygon');
var bodyParser = require("body-parser");
var titleCase = require('title-case');
var PropertiesReader = require('properties-reader');
var propertiesReader = PropertiesReader('./Properties.js'); 

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

var connection = mysql.createConnection({
	host     : propertiesReader.get('mysql.host'),
	user     : propertiesReader.get('mysql.user'),
	password : propertiesReader.get('mysql.password'),
	database : propertiesReader.get('mysql.database')
});

function insertAreaData(areaName, coordinates, callback){
	var obj = {};
	obj['area_name'] = areaName;
	obj['area_coordinates'] = coordinates.substring(1, coordinates.length);
	console.log(obj)
	connection.query('INSERT INTO area SET ?', obj, function (error, results, fields) {	
		if (error) throw error;
		callback('Data inserted successfully for location '+areaName);
	});
}

function fetchAreaData(callback){
	connection.query('select * from area', function (error, results, fields) {
		if (error) throw error;
		callback(results);
	});
}

function fetchData(callback){
	connection.query('select * from area order by id desc limit 5', function (error, results, fields) {
		if (error) throw error;
		callback(results);
	});
}

function findAreaName(point, dataObject,callback){
	
	var xpoint = parseFloat(point.split(',')[0]);
	var ypoint = parseFloat(point.split(',')[1]);
	var newPoints = [xpoint, ypoint];
	var location = '';
	var flag = false;
	var finalString = [];
	
	for(var i in dataObject){
		var polygon = [];
		var temp = dataObject[i].area_coordinates.split(':');
		for(var j in temp){
			var x = parseFloat(temp[j].split(',')[0]);
			var y = parseFloat(temp[j].split(',')[1]);
			var arr = [];
			arr.push(x);
			arr.push(y);
			polygon.push(arr);
		}
		if(inside(newPoints, polygon)){
			finalString.push(dataObject[i].area_name);
		}
	}
	if(finalString.length > 0){
		callback(finalString.toString());
	}else{
		callback('No location for given coordinates');
	}	
}

app.get('/markarea', function(req, res) {
    res.sendFile(__dirname + '/index.html');
});

app.get('/findarea', function(req, res) {
    res.sendFile(__dirname + '/next.html');
});

app.get('/fetchData', function(req, res) {
    fetchData(function(data){		
		res.json(data);
	});
});

app.post('/insertData',function(req,res){
	var area_name = titleCase(req.body.areaName);
	var area_coordinates = req.body.area_coordinates;
	insertAreaData(area_name, area_coordinates, function(response){		
		res.json(response);
	});
});

app.post('/findArea',function(req,res){
	var point = req.body.point;
	fetchAreaData(function(dataObject){	
		findAreaName(point, dataObject, function(response){	
			res.json(response);
		});	
	});
});

app.listen(4000, function() {
    console.log('listening on localhost:4000');
});