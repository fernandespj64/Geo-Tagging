var x1 = 19.076;
var x2 = 17.6136;
var y1 = 72.8777;
var y2 = 76.0595;

function myMap() {
	var mapProp= {
		center:new google.maps.LatLng(20.5937,78.9629),
		zoom:6,
	};
	var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
	
}

function fetchAllAreaDetails(){
	$.get("http://localhost:4000/fetchData", function(data, status){
		if(data.length > 0){
			for(var i in data){
				var area = data[i].area_name;
				var temp =data[i].area_coordinates;
				$('#details').append();
			}	
		}
	   
    });
}

function submitArea(){
	var areaName = $('#areaname').val();
	var pointOne = x1+','+y2;
	var pointTwo = x2+','+y2;
	var pointThree = x2+','+y1;
	var pointFour = x1+','+y1;
	
	var object = {
		"areaName" : areaName,
		"pointOne" : pointOne,
		"pointTwo" : pointTwo,
		"pointThree" : pointThree,
		"pointFour" : pointFour
	}
	
	if(areaName.length > 0){	
		$.post("http://localhost:4000/insertData",object, function(data){
			alert(data);
		});
	}else{
		alert('Area is mandatory field');
	}
	
}



function clearArea(){
	$('#areaname').val('');
	myMap();
}

$( document ).ready(function() {
    fetchAllAreaDetails();
});