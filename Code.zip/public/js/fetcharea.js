function myMap() {
	var mapProp= {
		center:new google.maps.LatLng(20.5937,78.9629),
		zoom:5,
	};
	var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
}

function fetchAllAreaDetails(){
	$.get("http://localhost:4000/fetchData", function(data, status){
		if(data.length > 0){
			for(var i in data){
				var area = data[i].area_name;
				var temp = data[i].area_coordinates.split(':');
				var array = '[';
				for(var j in temp){
					var arr = '';
					arr = ' [ ' + temp[j].split(',')[0] + ' , ';
					arr = arr + temp[j].split(',')[1] + ' ] , ';
					array = array + arr;
				}
				$('#details').append('<tr><td>'+area+'</td><td>'+array.slice(0, -2)+']'+'</td></tr>');
			}	
		}
    });
}

function prevPage(){
	window.location.replace("http://localhost:4000/markarea");
}

function submitArea1(){
	document.getElementById('areaInfo').innerHTML = '';
	var coordinates = document.getElementById("info");
	var data = '';
	if(coordinates){
		data = coordinates.innerHTML;
	}
	var a = data.split(',')[0].trim();
	var b = data.split(',')[1].trim();
	var object = {
		"point" : a+','+b
	}
	$.post("http://localhost:4000/findArea",object, function(data){
		if(data.includes('No location')){
			alert(data);
		}else{
			document.getElementById('areaInfo').innerHTML = data;
		}
		
	});
}

function clearArea1(){
	document.getElementById('areaInfo').innerHTML = '';
	$('#areaname').val('');
	initialize();
}

$( document ).ready(function() {
    fetchAllAreaDetails();
});