var x1 = 19.076;
var x2 = 17.6136;
var y1 = 72.8777;
var y2 = 76.0595;

function myMap() {
	var mapProp= {
		center:new google.maps.LatLng(20.5937,78.9629),
		zoom:6,
	};
	var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);

	var bounds = {
		north: 19.076,
		south: 17.6136,
		east: 76.0595,
		west: 72.8777
	};

	// Define a rectangle and set its editable property to true.
	var rectangle = new google.maps.Rectangle({
		bounds: bounds,
		editable: true,
		draggable: true
	});
	rectangle.setMap(map);
	
	// Add an event listener on the rectangle.
	rectangle.addListener('bounds_changed', showNewRect);

	// Define an info window on the map.
	infoWindow = new google.maps.InfoWindow();
	var ne = rectangle.getBounds().getNorthEast();
	var sw = rectangle.getBounds().getSouthWest();
	var contentString = '<b>Selected Area</b><br>'+'North-East corner: '+ne.lat()+', '+ne.lng()+'<br>'+'South-West corner: '+sw.lat()+', '+sw.lng();
	infoWindow.setContent(contentString);
	infoWindow.setPosition(ne);
	infoWindow.open(map);
		
	function showNewRect(event) {
        var ne = rectangle.getBounds().getNorthEast();
        var sw = rectangle.getBounds().getSouthWest();

        var contentString = '<b>Selected Area</b><br>' +
            'North-East corner: ' + ne.lat() + ', ' + ne.lng() + '<br>' +
            'South-West corner: ' + sw.lat() + ', ' + sw.lng();
			
		x1 = ne.lat();
		y2 = ne.lng();
		
		x2 = sw.lat();
		y1 = sw.lng();
		
        // Set the info window's content and position.
        infoWindow.setContent(contentString);
        infoWindow.setPosition(ne);

        infoWindow.open(map);
      }
	
}

function submitArea(){
	var areaName = $('#areaname').val();
	var pointOne = x1+','+y2;
	var pointTwo = x2+','+y2;
	var pointThree = x2+','+y1;
	var pointFour = x1+','+y1;
	
	var object = {
		"areaName" : areaName,
		"pointOne" : pointOne,
		"pointTwo" : pointTwo,
		"pointThree" : pointThree,
		"pointFour" : pointFour
	}
	
	if(areaName.length > 0){	
		$.post("http://localhost:4000/insertData",object, function(data){
			alert(data);
		});
	}else{
		alert('Area is mandatory field');
	}
	
}

function clearArea(){
	$('#areaname').val('');
	myMap();
}