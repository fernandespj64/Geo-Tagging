var map;
var polygonArray = [];
function myMap() {
    map = new google.maps.Map(
	
    document.getElementById("googleMap"), {
        center: new google.maps.LatLng(20.5937,78.9629),
        zoom: 5
    });
	
    var drawingManager = new google.maps.drawing.DrawingManager({
        drawingMode: google.maps.drawing.OverlayType.POLYGON,
        drawingControl: false,
        polygonOptions: {
            fillColor: '#BCDCF9',
            fillOpacity: 0.5,
            strokeWeight: 2,
            strokeColor: '#57ACF9',
            clickable: true,
            zIndex: 1
        }
    });
    
    drawingManager.setMap(map)

    google.maps.event.addListener(drawingManager, 'polygoncomplete', function (polygon) {
        infoWindow = new google.maps.InfoWindow();
		polygonArray = [];
		var contentString = '';
        for (var i = 0; i < polygon.getPath().getLength(); i++) {
			console.log(polygon.getPath().getAt(i).toUrlValue(6))
            polygonArray.push(polygon.getPath().getAt(i).toUrlValue(6));
			contentString = contentString + ' [ ' + polygon.getPath().getAt(i).toUrlValue(6) + ' ] ';
        }
		infoWindow.setContent('[ '+contentString+' ]');
		position = new google.maps.LatLng(parseFloat(polygonArray[0].split(',')[0]),parseFloat(polygonArray[0].split(',')[1]));
		infoWindow.setPosition(position);
		infoWindow.open(map);
		
		drawingManager.setMap(null);
		
    });
}

function roundOff(value){
	var val = parseFloat(value);
	return Math.round(val * 10000) / 10000;
}

function submitArea(){
	var areaName = $('#areaname').val();
	if(polygonArray.length > 0){
		if(areaName.length > 0){	
		
			var coordinates = '';
		
			for(var p in polygonArray){
				var temp = polygonArray[p].split(',');
				var lat = roundOff(temp[0]);
				var lon = roundOff(temp[1]);
				coordinates = coordinates + ':' +(lat+','+lon);
			}
			var object = {
				"areaName" : areaName,
				"area_coordinates" : coordinates		
			}
			$.post("http://localhost:4000/insertData",object, function(data){
				$('#areaname').val('');
				alert(data);
			});
		}else{
			alert('Area is mandatory field');
		}	
	}else{
		alert('Please select an area by clicking on the map');
	}
}

function nextPage(){
	window.location.replace("http://localhost:4000/findarea");
}

function clearArea(){
	$('#areaname').val('');
	myMap();
}