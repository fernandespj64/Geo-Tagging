
--
-- Create schema geo_tagging
--

CREATE DATABASE IF NOT EXISTS geo_tagging;
USE geo_tagging;

--
-- Definition of table `area`
--

DROP TABLE IF EXISTS `area`;
CREATE TABLE `area` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `area_name` varchar(200) NOT NULL,
  `area_coordinates` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

